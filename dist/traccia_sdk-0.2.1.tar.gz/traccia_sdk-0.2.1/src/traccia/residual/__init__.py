﻿from .engine import ResidualCaptureEngine
